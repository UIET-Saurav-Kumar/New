<?php

namespace PickBazar\Database\Models;

use Illuminate\Database\Eloquent\Model;

class ReferralCommission extends Model
{
	protected $table = 'referral_commissions';

	public $guarded = [];
}
